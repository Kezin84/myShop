<template>
  <div class="container py-5">
    <h2 class="mb-4 text-primary text-center">🌟 Chào mừng đến với TechShop!</h2>
    <p class="lead text-center">
      TechShop là cửa hàng trực tuyến chuyên cung cấp các sản phẩm thời trang chất lượng cao, phù hợp với mọi lứa tuổi và phong cách sống hiện đại.
    </p>

    <div class="row mt-5">
      <div class="col-md-6">
        <h4 class="text-success">💼 Sứ mệnh của chúng tôi</h4>
        <p>
          Cung cấp sản phẩm uy tín, dịch vụ chu đáo và trải nghiệm mua sắm dễ dàng cho mọi khách hàng, dù bạn ở bất cứ đâu.
        </p>
        <h4 class="text-success">🎯 Tầm nhìn</h4>
        <p>
          Trở thành nền tảng thương mại điện tử thân thiện và được yêu thích hàng đầu trong lĩnh vực thời trang tại Việt Nam.
        </p>
      </div>
      <div class="col-md-6">
        <img
          src="https://cdn.pixabay.com/photo/2016/11/29/04/17/business-1869510_1280.jpg"
          alt="about"
          class="img-fluid rounded shadow"
        />
      </div>
    </div>

    <div class="row mt-5">
      <div class="col-md-4 text-center">
        <h5>🚚 Giao hàng toàn quốc</h5>
        <p>Đảm bảo đơn hàng đến tay bạn nhanh chóng và an toàn.</p>
      </div>
      <div class="col-md-4 text-center">
        <h5>🔒 Bảo mật tuyệt đối</h5>
        <p>Thông tin cá nhân và đơn hàng của bạn được bảo vệ nghiêm ngặt.</p>
      </div>
      <div class="col-md-4 text-center">
        <h5>☎️ Hỗ trợ 24/7</h5>
        <p>Chúng tôi luôn sẵn sàng giải đáp mọi thắc mắc của bạn.</p>
      </div>
    </div>

    <div class="mt-5 text-center">
     
    </div>
  </div>
</template>

<script setup>
import { RouterLink } from 'vue-router'
</script>

<style scoped>
p {
  font-size: 16px;
  line-height: 1.6;
}
</style>